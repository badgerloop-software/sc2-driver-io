## telemetrylib
telemetrylib contains classes made for specific communication methods, and communication channel switching logic, each communication method is a implementation of the Data telemetry interface (DTI), to use the library, create an array of DTI object with order of priority, and use the array to initialize telemetrylib.
